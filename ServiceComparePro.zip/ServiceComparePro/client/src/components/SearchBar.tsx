import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, SlidersHorizontal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { useState } from "react";

interface SearchBarProps {
  onSearch?: (query: string) => void;
  onFilterClick?: () => void;
  placeholder?: string;
  filters?: { label: string; value: string }[];
  onRemoveFilter?: (value: string) => void;
}

export default function SearchBar({
  onSearch,
  onFilterClick,
  placeholder = "Search by name or subject...",
  filters = [],
  onRemoveFilter,
}: SearchBarProps) {
  const [searchValue, setSearchValue] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchValue);
  };

  return (
    <div className="space-y-3">
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder={placeholder}
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>
        <Button type="submit" data-testid="button-search">
          Search
        </Button>
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={onFilterClick}
          data-testid="button-filters"
        >
          <SlidersHorizontal className="h-4 w-4" />
        </Button>
      </form>

      {filters.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {filters.map((filter) => (
            <Badge
              key={filter.value}
              variant="secondary"
              className="pl-3 pr-1 py-1"
              data-testid={`badge-filter-${filter.value}`}
            >
              {filter.label}
              <Button
                variant="ghost"
                size="icon"
                className="h-4 w-4 ml-1 p-0 hover:bg-transparent"
                onClick={() => onRemoveFilter?.(filter.value)}
                data-testid={`button-remove-filter-${filter.value}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
