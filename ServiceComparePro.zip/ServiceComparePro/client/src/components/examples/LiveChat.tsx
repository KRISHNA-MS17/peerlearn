import { useState } from "react";
import LiveChat from '../LiveChat';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function LiveChatExample() {
  const [messages, setMessages] = useState([
    {
      id: "1",
      userId: "user1",
      userName: "Alex Chen",
      userAvatar: avatar1,
      message: "Great explanation of derivatives!",
      timestamp: new Date(Date.now() - 300000),
    },
    {
      id: "2",
      userId: "user2",
      userName: "Sarah Johnson",
      userAvatar: avatar2,
      message: "Can you explain that part about chain rule again?",
      timestamp: new Date(Date.now() - 240000),
    },
    {
      id: "3",
      userId: "me",
      userName: "You",
      message: "This is really helpful, thanks!",
      timestamp: new Date(Date.now() - 180000),
    },
    {
      id: "4",
      userId: "user1",
      userName: "Alex Chen",
      userAvatar: avatar1,
      message: "Sure! The chain rule is used when you have a composition of functions...",
      timestamp: new Date(Date.now() - 120000),
    },
  ]);

  const handleSendMessage = (message: string) => {
    const newMessage = {
      id: Date.now().toString(),
      userId: "me",
      userName: "You",
      message,
      timestamp: new Date(),
    };
    setMessages([...messages, newMessage]);
  };

  return (
    <div className="max-w-md h-[600px] p-6">
      <LiveChat
        messages={messages}
        onSendMessage={handleSendMessage}
        currentUserId="me"
      />
    </div>
  );
}
