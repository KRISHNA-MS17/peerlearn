import { useState } from "react";
import CommentSection from '../CommentSection';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function CommentSectionExample() {
  const [comments, setComments] = useState<any[]>([
    {
      id: "1",
      userId: "user1",
      userName: "Alex Chen",
      userAvatar: avatar1,
      content: "This was such a helpful stream! The way you explained derivatives really clicked for me.",
      timestamp: new Date(Date.now() - 7200000),
      likes: 12,
      hasLiked: false,
      replies: [
        {
          id: "1-1",
          userId: "user2",
          userName: "Sarah Johnson",
          userAvatar: avatar2,
          content: "I agree! The examples were really clear.",
          timestamp: new Date(Date.now() - 3600000),
          likes: 3,
          hasLiked: false,
        },
      ],
    },
    {
      id: "2",
      userId: "user3",
      userName: "Jordan Lee",
      content: "Could you do a follow-up stream on integrals? Would love to see that!",
      timestamp: new Date(Date.now() - 5400000),
      likes: 8,
      hasLiked: true,
    },
    {
      id: "3",
      userId: "user2",
      userName: "Sarah Johnson",
      userAvatar: avatar2,
      content: "Thanks for streaming! This helped me prepare for my exam tomorrow.",
      timestamp: new Date(Date.now() - 1800000),
      likes: 5,
      hasLiked: false,
    },
  ]);

  const handleAddComment = (content: string, parentId?: string) => {
    const newComment = {
      id: Date.now().toString(),
      userId: "me",
      userName: "You",
      content,
      timestamp: new Date(),
      likes: 0,
      hasLiked: false,
    };

    if (parentId) {
      setComments(
        comments.map((c) =>
          c.id === parentId
            ? { ...c, replies: [...(c.replies || []), newComment] }
            : c
        )
      );
    } else {
      setComments([...comments, newComment]);
    }
  };

  const handleLikeComment = (commentId: string) => {
    console.log('Like comment:', commentId);
  };

  return (
    <div className="max-w-3xl p-6">
      <CommentSection
        comments={comments}
        onAddComment={handleAddComment}
        onLikeComment={handleLikeComment}
      />
    </div>
  );
}
