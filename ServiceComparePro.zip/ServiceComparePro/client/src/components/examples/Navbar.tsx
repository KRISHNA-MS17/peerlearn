import Navbar from '../Navbar';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';

export default function NavbarExample() {
  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm text-muted-foreground mb-2">Logged out state:</p>
        <Navbar 
          isLoggedIn={false}
          onAuthClick={() => console.log('Auth clicked')}
        />
      </div>
      <div>
        <p className="text-sm text-muted-foreground mb-2">Logged in state with notifications:</p>
        <Navbar 
          isLoggedIn={true}
          pendingRequestsCount={3}
          userName="Alex Chen"
          userAvatar={avatar1}
        />
      </div>
    </div>
  );
}
