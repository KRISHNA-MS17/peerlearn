import ConnectionRequest from '../ConnectionRequest';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function ConnectionRequestExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
      <ConnectionRequest
        id="1"
        name="Alex Chen"
        avatar={avatar1}
        subject="Mathematics"
        message="Hi! I saw you're good at calculus. I'd love to connect and get some help with derivatives."
        timestamp="2 hours ago"
        onAccept={(id) => console.log('Accepted request', id)}
        onDecline={(id) => console.log('Declined request', id)}
      />
      <ConnectionRequest
        id="2"
        name="Sarah Johnson"
        avatar={avatar2}
        subject="Physics"
        message="I need help with quantum mechanics. Can you help?"
        timestamp="1 day ago"
        onAccept={(id) => console.log('Accepted request', id)}
        onDecline={(id) => console.log('Declined request', id)}
      />
      <ConnectionRequest
        id="3"
        name="Jordan Lee"
        subject="Chemistry"
        timestamp="3 days ago"
        status="accepted"
      />
    </div>
  );
}
