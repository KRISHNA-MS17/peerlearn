import LiveStreamCard from '../LiveStreamCard';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function LiveStreamCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <LiveStreamCard
        id="1"
        title="Calculus Study Session - Derivatives & Integrals Explained"
        streamerName="Alex Chen"
        streamerAvatar={avatar1}
        subject="Mathematics"
        viewerCount={42}
        isLive={true}
        onClick={(id) => console.log('Clicked stream', id)}
      />
      <LiveStreamCard
        id="2"
        title="Physics Problem Solving - Mechanics & Forces"
        streamerName="Sarah Johnson"
        streamerAvatar={avatar2}
        subject="Physics"
        viewerCount={28}
        isLive={true}
        onClick={(id) => console.log('Clicked stream', id)}
      />
      <LiveStreamCard
        id="3"
        title="Chemistry Lab Review - Organic Compounds"
        streamerName="Jordan Lee"
        subject="Chemistry"
        viewerCount={15}
        isLive={false}
        duration="1:24:15"
        onClick={(id) => console.log('Clicked stream', id)}
      />
    </div>
  );
}
