import DashboardStats from '../DashboardStats';

export default function DashboardStatsExample() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <p className="text-sm text-muted-foreground mb-3">Active user stats:</p>
        <DashboardStats
          matches={8}
          pendingRequests={3}
          totalSessions={24}
          averageRating={4.8}
        />
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-3">New user stats:</p>
        <DashboardStats
          matches={0}
          pendingRequests={0}
          totalSessions={0}
          averageRating={0}
        />
      </div>
    </div>
  );
}
