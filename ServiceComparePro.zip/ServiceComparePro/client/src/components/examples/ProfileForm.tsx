import ProfileForm from '../ProfileForm';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';

export default function ProfileFormExample() {
  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Edit Your Profile</h2>
      <ProfileForm
        initialData={{
          name: "Alex Chen",
          bio: "Computer Science student passionate about helping others learn programming.",
          avatar: avatar1,
          subjectsTeaching: ["Mathematics", "Computer Science"],
          subjectsLearning: ["Physics"],
          availability: "Mon-Fri evenings",
        }}
        onSubmit={(data) => console.log('Profile submitted:', data)}
      />
    </div>
  );
}
