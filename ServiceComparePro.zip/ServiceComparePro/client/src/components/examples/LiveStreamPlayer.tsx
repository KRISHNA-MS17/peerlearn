import LiveStreamPlayer from '../LiveStreamPlayer';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';

export default function LiveStreamPlayerExample() {
  return (
    <div className="max-w-4xl p-6 space-y-6">
      <LiveStreamPlayer
        streamTitle="Calculus Study Session - Derivatives & Integrals"
        streamerName="Alex Chen"
        streamerAvatar={avatar1}
        subject="Mathematics"
        viewerCount={42}
        isLive={true}
      />
    </div>
  );
}
