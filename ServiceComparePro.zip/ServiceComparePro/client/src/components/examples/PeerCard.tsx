import PeerCard from '../PeerCard';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function PeerCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <PeerCard
        id="1"
        name="Alex Chen"
        avatar={avatar1}
        subjectsTeaching={["Mathematics", "Physics"]}
        subjectsLearning={["Chemistry", "Biology"]}
        rating={4.8}
        reviewCount={23}
        availability="Available Mon-Fri evenings"
        onConnect={(id) => console.log('Connect clicked for', id)}
        onMessage={(id) => console.log('Message clicked for', id)}
      />
      <PeerCard
        id="2"
        name="Sarah Johnson"
        avatar={avatar2}
        subjectsTeaching={["English Literature", "History"]}
        subjectsLearning={["Mathematics"]}
        rating={4.9}
        reviewCount={45}
        availability="Weekends only"
        connected={true}
        onConnect={(id) => console.log('Connect clicked for', id)}
        onMessage={(id) => console.log('Message clicked for', id)}
      />
      <PeerCard
        id="3"
        name="Jordan Lee"
        subjectsTeaching={["Computer Science", "Web Development"]}
        subjectsLearning={["Data Structures"]}
        rating={5.0}
        reviewCount={12}
        onConnect={(id) => console.log('Connect clicked for', id)}
        onMessage={(id) => console.log('Message clicked for', id)}
      />
    </div>
  );
}
