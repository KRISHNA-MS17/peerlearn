import SearchBar from '../SearchBar';

export default function SearchBarExample() {
  return (
    <div className="max-w-2xl p-6 space-y-6">
      <div>
        <p className="text-sm text-muted-foreground mb-3">Basic search:</p>
        <SearchBar
          onSearch={(query) => console.log('Search:', query)}
          onFilterClick={() => console.log('Filters clicked')}
        />
      </div>
      
      <div>
        <p className="text-sm text-muted-foreground mb-3">With active filters:</p>
        <SearchBar
          onSearch={(query) => console.log('Search:', query)}
          onFilterClick={() => console.log('Filters clicked')}
          filters={[
            { label: "Mathematics", value: "math" },
            { label: "Rating 4+", value: "rating-4" },
            { label: "Available Now", value: "available" },
          ]}
          onRemoveFilter={(value) => console.log('Remove filter:', value)}
        />
      </div>
    </div>
  );
}
