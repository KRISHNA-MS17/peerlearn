import MessageThread from '../MessageThread';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';

export default function MessageThreadExample() {
  const sampleMessages = [
    {
      id: "1",
      senderId: "peer",
      content: "Hey! Thanks for connecting. When are you free for a study session?",
      timestamp: new Date(Date.now() - 3600000),
      isOwn: false,
    },
    {
      id: "2",
      senderId: "me",
      content: "Hi! I'm available tomorrow evening around 6 PM. Does that work for you?",
      timestamp: new Date(Date.now() - 3000000),
      isOwn: true,
    },
    {
      id: "3",
      senderId: "peer",
      content: "Perfect! Let's meet at the library. I'll bring my calculus notes.",
      timestamp: new Date(Date.now() - 2400000),
      isOwn: false,
    },
    {
      id: "4",
      senderId: "me",
      content: "Sounds great! See you then.",
      timestamp: new Date(Date.now() - 1800000),
      isOwn: true,
    },
  ];

  return (
    <div className="max-w-3xl p-6">
      <MessageThread
        peerName="Alex Chen"
        peerAvatar={avatar1}
        messages={sampleMessages}
        onSendMessage={(content) => console.log('Send message:', content)}
      />
    </div>
  );
}
