import ReviewCard from '../ReviewCard';
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function ReviewCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
      <ReviewCard
        id="1"
        reviewerName="Alex Chen"
        reviewerAvatar={avatar1}
        rating={5}
        comment="Excellent tutor! Very patient and explains concepts clearly. Really helped me understand calculus."
        subject="Mathematics"
        timestamp="2 days ago"
      />
      <ReviewCard
        id="2"
        reviewerName="Sarah Johnson"
        reviewerAvatar={avatar2}
        rating={4}
        comment="Great session! Would definitely recommend. Very knowledgeable about the subject."
        subject="Physics"
        timestamp="1 week ago"
      />
      <ReviewCard
        id="3"
        reviewerName="Jordan Lee"
        rating={5}
        comment="Amazing help with my chemistry homework. Made everything so much easier to understand!"
        subject="Chemistry"
        timestamp="2 weeks ago"
      />
    </div>
  );
}
