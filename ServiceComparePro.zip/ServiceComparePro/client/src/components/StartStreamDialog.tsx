import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Video, Loader2 } from "lucide-react";

const SUBJECTS = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "English",
  "History",
  "Computer Science",
  "Economics",
];

interface StartStreamDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartStream?: (data: StreamData) => void;
}

export interface StreamData {
  title: string;
  description: string;
  subject: string;
}

export default function StartStreamDialog({
  open,
  onOpenChange,
  onStartStream,
}: StartStreamDialogProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [subject, setSubject] = useState("");
  const [isStarting, setIsStarting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsStarting(true);
    
    // Simulate stream setup
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    onStartStream?.({ title, description, subject });
    setIsStarting(false);
    
    // Reset form
    setTitle("");
    setDescription("");
    setSubject("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg" data-testid="dialog-start-stream">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="h-5 w-5 text-primary" />
            Start Live Study Session
          </DialogTitle>
          <DialogDescription>
            Set up your live stream to teach and help other students in real-time
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="stream-title">Stream Title *</Label>
            <Input
              id="stream-title"
              placeholder="e.g., Calculus Study Session - Derivatives"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              data-testid="input-stream-title"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="stream-subject">Subject *</Label>
            <Select value={subject} onValueChange={setSubject} required>
              <SelectTrigger id="stream-subject" data-testid="select-subject">
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                {SUBJECTS.map((subj) => (
                  <SelectItem key={subj} value={subj}>
                    {subj}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="stream-description">Description</Label>
            <Textarea
              id="stream-description"
              placeholder="What topics will you cover in this session?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="resize-none min-h-24"
              data-testid="input-stream-description"
            />
          </div>

          <div className="bg-muted/50 rounded-lg p-4 text-sm space-y-2">
            <p className="font-medium">Before you start:</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Make sure your camera and microphone are working</li>
              <li>Find a quiet, well-lit space</li>
              <li>Prepare any materials you want to share</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
              disabled={isStarting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={isStarting || !title || !subject}
              data-testid="button-start-broadcasting"
            >
              {isStarting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Video className="mr-2 h-4 w-4" />
                  Start Broadcasting
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
