import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Play, Pause, Volume2, VolumeX, Maximize, Users, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";

interface LiveStreamPlayerProps {
  streamTitle: string;
  streamerName: string;
  streamerAvatar?: string;
  subject: string;
  viewerCount?: number;
  isLive?: boolean;
  thumbnailUrl?: string;
}

export default function LiveStreamPlayer({
  streamTitle,
  streamerName,
  streamerAvatar,
  subject,
  viewerCount = 0,
  isLive = true,
  thumbnailUrl,
}: LiveStreamPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(false);

  const initials = streamerName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="overflow-hidden" data-testid="live-stream-player">
      <div
        className="relative bg-black aspect-video group"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        {/* Video placeholder - in production this would be actual video element */}
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
          {thumbnailUrl ? (
            <img src={thumbnailUrl} alt={streamTitle} className="w-full h-full object-cover" />
          ) : (
            <div className="text-white/50 text-center">
              <Play className="h-16 w-16 mx-auto mb-2" />
              <p className="text-sm">Live Stream Video Player</p>
            </div>
          )}
        </div>

        {/* Live badge */}
        {isLive && (
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <Badge variant="destructive" className="animate-pulse">
              <div className="h-2 w-2 rounded-full bg-white mr-2" />
              LIVE
            </Badge>
            <Badge variant="secondary" className="backdrop-blur-sm bg-black/50 text-white">
              <Eye className="h-3 w-3 mr-1" />
              {viewerCount} watching
            </Badge>
          </div>
        )}

        {/* Video controls */}
        <div
          className={`absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent transition-opacity ${
            showControls ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="absolute bottom-0 left-0 right-0 p-4 space-y-3">
            {/* Progress bar */}
            <div className="h-1 bg-white/30 rounded-full overflow-hidden">
              <div className="h-full bg-primary w-0" />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                  onClick={() => setIsPlaying(!isPlaying)}
                  data-testid="button-play-pause"
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                  onClick={() => setIsMuted(!isMuted)}
                  data-testid="button-mute"
                >
                  {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </Button>
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="text-white hover:bg-white/20"
                onClick={() => console.log("Fullscreen")}
                data-testid="button-fullscreen"
              >
                <Maximize className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Stream info */}
      <div className="p-4 space-y-3">
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={streamerAvatar} alt={streamerName} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg mb-1" data-testid="text-stream-title">
              {streamTitle}
            </h3>
            <p className="text-sm text-muted-foreground">{streamerName}</p>
          </div>
          <Badge variant="default">{subject}</Badge>
        </div>
      </div>
    </Card>
  );
}
