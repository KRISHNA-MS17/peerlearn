import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  timestamp: Date;
  likes: number;
  hasLiked: boolean;
  replies?: Comment[];
}

interface CommentSectionProps {
  comments: Comment[];
  onAddComment?: (content: string, parentId?: string) => void;
  onLikeComment?: (commentId: string) => void;
  currentUserId?: string;
}

function CommentItem({
  comment,
  onLike,
  onReply,
  isReply = false,
}: {
  comment: Comment;
  onLike?: (id: string) => void;
  onReply?: (id: string) => void;
  isReply?: boolean;
}) {
  const initials = comment.userName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className={`space-y-3 ${isReply ? "ml-12" : ""}`} data-testid={`comment-${comment.id}`}>
      <div className="flex gap-3">
        <Avatar className="h-10 w-10 shrink-0">
          <AvatarImage src={comment.userAvatar} alt={comment.userName} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-semibold text-sm">{comment.userName}</span>
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(comment.timestamp, { addSuffix: true })}
            </span>
          </div>
          <p className="text-sm text-foreground mb-2">{comment.content}</p>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 gap-1 ${comment.hasLiked ? "text-primary" : ""}`}
              onClick={() => onLike?.(comment.id)}
              data-testid={`button-like-${comment.id}`}
            >
              <ThumbsUp className={`h-3 w-3 ${comment.hasLiked ? "fill-current" : ""}`} />
              <span className="text-xs">{comment.likes}</span>
            </Button>
            {!isReply && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1"
                onClick={() => onReply?.(comment.id)}
                data-testid={`button-reply-${comment.id}`}
              >
                <MessageCircle className="h-3 w-3" />
                <span className="text-xs">Reply</span>
              </Button>
            )}
          </div>
        </div>
      </div>
      {comment.replies && comment.replies.length > 0 && (
        <div className="space-y-3">
          {comment.replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              onLike={onLike}
              isReply={true}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CommentSection({
  comments,
  onAddComment,
  onLikeComment,
}: CommentSectionProps) {
  const [commentText, setCommentText] = useState("");
  const [replyingTo, setReplyingTo] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      onAddComment?.(commentText, replyingTo || undefined);
      setCommentText("");
      setReplyingTo(null);
    }
  };

  return (
    <div className="space-y-6" data-testid="comment-section">
      <div>
        <h3 className="font-semibold text-lg mb-1">{comments.length} Comments</h3>
        <p className="text-sm text-muted-foreground">
          Share your thoughts about this stream
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <Textarea
          placeholder="Add a comment..."
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
          className="resize-none min-h-20"
          data-testid="input-comment"
        />
        <div className="flex justify-between items-center">
          {replyingTo && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setReplyingTo(null)}
              type="button"
            >
              Cancel Reply
            </Button>
          )}
          <div className="ml-auto">
            <Button type="submit" data-testid="button-post-comment">
              Post Comment
            </Button>
          </div>
        </div>
      </form>

      <div className="space-y-6">
        {comments.map((comment) => (
          <CommentItem
            key={comment.id}
            comment={comment}
            onLike={onLikeComment}
            onReply={setReplyingTo}
          />
        ))}
      </div>
    </div>
  );
}
