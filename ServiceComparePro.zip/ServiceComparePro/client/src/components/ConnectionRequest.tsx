import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Check, X } from "lucide-react";

interface ConnectionRequestProps {
  id: string;
  name: string;
  avatar?: string;
  subject: string;
  message?: string;
  timestamp: string;
  onAccept?: (id: string) => void;
  onDecline?: (id: string) => void;
  status?: "pending" | "accepted" | "declined";
}

export default function ConnectionRequest({
  id,
  name,
  avatar,
  subject,
  message,
  timestamp,
  onAccept,
  onDecline,
  status = "pending",
}: ConnectionRequestProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card data-testid={`card-request-${id}`}>
      <CardHeader className="flex flex-row items-start gap-4 space-y-0 pb-3">
        <Avatar className="h-12 w-12">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold truncate" data-testid={`text-requester-${id}`}>{name}</h3>
            <Badge variant="default" className="text-xs shrink-0" data-testid={`badge-subject-${id}`}>
              {subject}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-1">{timestamp}</p>
        </div>
      </CardHeader>

      {message && (
        <CardContent className="pb-3">
          <p className="text-sm text-muted-foreground" data-testid={`text-message-${id}`}>"{message}"</p>
        </CardContent>
      )}

      <CardFooter className="flex gap-2">
        {status === "pending" ? (
          <>
            <Button
              variant="default"
              className="flex-1"
              onClick={() => onAccept?.(id)}
              data-testid={`button-accept-${id}`}
            >
              <Check className="h-4 w-4 mr-2" />
              Accept
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onDecline?.(id)}
              data-testid={`button-decline-${id}`}
            >
              <X className="h-4 w-4 mr-2" />
              Decline
            </Button>
          </>
        ) : status === "accepted" ? (
          <Badge variant="default" className="w-full justify-center">Accepted</Badge>
        ) : (
          <Badge variant="secondary" className="w-full justify-center">Declined</Badge>
        )}
      </CardFooter>
    </Card>
  );
}
