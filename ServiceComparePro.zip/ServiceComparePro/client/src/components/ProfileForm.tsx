import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { X, Plus } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const COMMON_SUBJECTS = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "English",
  "History",
  "Computer Science",
  "Economics",
  "Psychology",
  "Statistics",
];

interface ProfileFormProps {
  onSubmit?: (data: ProfileFormData) => void;
  initialData?: Partial<ProfileFormData>;
}

export interface ProfileFormData {
  name: string;
  bio: string;
  avatar: string;
  subjectsTeaching: string[];
  subjectsLearning: string[];
  availability: string;
}

export default function ProfileForm({ onSubmit, initialData }: ProfileFormProps) {
  const [name, setName] = useState(initialData?.name || "");
  const [bio, setBio] = useState(initialData?.bio || "");
  const [avatar, setAvatar] = useState(initialData?.avatar || "");
  const [subjectsTeaching, setSubjectsTeaching] = useState<string[]>(
    initialData?.subjectsTeaching || []
  );
  const [subjectsLearning, setSubjectsLearning] = useState<string[]>(
    initialData?.subjectsLearning || []
  );
  const [availability, setAvailability] = useState(initialData?.availability || "");
  const [customSubject, setCustomSubject] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit?.({
      name,
      bio,
      avatar,
      subjectsTeaching,
      subjectsLearning,
      availability,
    });
  };

  const addSubject = (subject: string, list: "teaching" | "learning") => {
    if (list === "teaching" && !subjectsTeaching.includes(subject)) {
      setSubjectsTeaching([...subjectsTeaching, subject]);
    } else if (list === "learning" && !subjectsLearning.includes(subject)) {
      setSubjectsLearning([...subjectsLearning, subject]);
    }
  };

  const removeSubject = (subject: string, list: "teaching" | "learning") => {
    if (list === "teaching") {
      setSubjectsTeaching(subjectsTeaching.filter((s) => s !== subject));
    } else {
      setSubjectsLearning(subjectsLearning.filter((s) => s !== subject));
    }
  };

  const addCustomSubject = (list: "teaching" | "learning") => {
    if (customSubject.trim()) {
      addSubject(customSubject.trim(), list);
      setCustomSubject("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-profile">
      <div className="flex flex-col items-center gap-4">
        <Avatar className="h-24 w-24">
          <AvatarImage src={avatar} />
          <AvatarFallback>{name.charAt(0).toUpperCase() || "U"}</AvatarFallback>
        </Avatar>
        <div className="w-full max-w-sm">
          <Label htmlFor="avatar">Profile Photo URL</Label>
          <Input
            id="avatar"
            type="url"
            placeholder="https://example.com/photo.jpg"
            value={avatar}
            onChange={(e) => setAvatar(e.target.value)}
            data-testid="input-avatar"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Full Name *</Label>
        <Input
          id="name"
          type="text"
          placeholder="Alex Chen"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          data-testid="input-name"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="bio">Bio</Label>
        <Textarea
          id="bio"
          placeholder="Tell peers about yourself and your learning goals..."
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          className="resize-none min-h-24"
          data-testid="input-bio"
        />
      </div>

      <div className="space-y-3">
        <Label>Subjects I Can Teach</Label>
        <div className="flex flex-wrap gap-2">
          {subjectsTeaching.map((subject) => (
            <Badge key={subject} variant="default" className="pl-3 pr-1 py-1" data-testid={`badge-teach-${subject}`}>
              {subject}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-4 w-4 ml-1 p-0 hover:bg-transparent"
                onClick={() => removeSubject(subject, "teaching")}
                data-testid={`button-remove-teach-${subject}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ))}
        </div>
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Add custom subject..."
            value={customSubject}
            onChange={(e) => setCustomSubject(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addCustomSubject("teaching"))}
            data-testid="input-custom-teach"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => addCustomSubject("teaching")}
            data-testid="button-add-custom-teach"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {COMMON_SUBJECTS.filter((s) => !subjectsTeaching.includes(s)).map((subject) => (
            <Button
              key={subject}
              type="button"
              variant="outline"
              size="sm"
              onClick={() => addSubject(subject, "teaching")}
              data-testid={`button-suggest-teach-${subject}`}
            >
              + {subject}
            </Button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <Label>Subjects I Want to Learn</Label>
        <div className="flex flex-wrap gap-2">
          {subjectsLearning.map((subject) => (
            <Badge key={subject} variant="secondary" className="pl-3 pr-1 py-1" data-testid={`badge-learn-${subject}`}>
              {subject}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-4 w-4 ml-1 p-0 hover:bg-transparent"
                onClick={() => removeSubject(subject, "learning")}
                data-testid={`button-remove-learn-${subject}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ))}
        </div>
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Add custom subject..."
            value={customSubject}
            onChange={(e) => setCustomSubject(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addCustomSubject("learning"))}
            data-testid="input-custom-learn"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => addCustomSubject("learning")}
            data-testid="button-add-custom-learn"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {COMMON_SUBJECTS.filter((s) => !subjectsLearning.includes(s)).map((subject) => (
            <Button
              key={subject}
              type="button"
              variant="outline"
              size="sm"
              onClick={() => addSubject(subject, "learning")}
              data-testid={`button-suggest-learn-${subject}`}
            >
              + {subject}
            </Button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="availability">Availability</Label>
        <Input
          id="availability"
          type="text"
          placeholder="e.g., Mon-Fri evenings, Weekends"
          value={availability}
          onChange={(e) => setAvailability(e.target.value)}
          data-testid="input-availability"
        />
      </div>

      <Button type="submit" className="w-full" data-testid="button-save-profile">
        Save Profile
      </Button>
    </form>
  );
}
