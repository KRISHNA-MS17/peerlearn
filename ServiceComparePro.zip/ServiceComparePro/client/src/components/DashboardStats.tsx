import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, MessageSquare, Clock, Star } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
}

function StatCard({ title, value, icon, description }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-4 w-4 text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold" data-testid={`stat-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}

interface DashboardStatsProps {
  matches?: number;
  pendingRequests?: number;
  totalSessions?: number;
  averageRating?: number;
}

export default function DashboardStats({
  matches = 0,
  pendingRequests = 0,
  totalSessions = 0,
  averageRating = 0,
}: DashboardStatsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="dashboard-stats">
      <StatCard
        title="Active Matches"
        value={matches}
        icon={<Users className="h-4 w-4" />}
        description="Connected peers"
      />
      <StatCard
        title="Pending Requests"
        value={pendingRequests}
        icon={<MessageSquare className="h-4 w-4" />}
        description="Awaiting response"
      />
      <StatCard
        title="Total Sessions"
        value={totalSessions}
        icon={<Clock className="h-4 w-4" />}
        description="Study sessions completed"
      />
      <StatCard
        title="Your Rating"
        value={averageRating > 0 ? averageRating.toFixed(1) : "N/A"}
        icon={<Star className="h-4 w-4" />}
        description="Average peer rating"
      />
    </div>
  );
}
