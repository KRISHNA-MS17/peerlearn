import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Bell, Menu, User, GraduationCap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface NavbarProps {
  isLoggedIn?: boolean;
  onAuthClick?: () => void;
  pendingRequestsCount?: number;
  userName?: string;
  userAvatar?: string;
}

export default function Navbar({
  isLoggedIn = false,
  onAuthClick,
  pendingRequestsCount = 0,
  userName = "Student",
  userAvatar,
}: NavbarProps) {
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link href="/">
            <a className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-lg px-3 py-2" data-testid="link-home">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold font-[family-name:var(--font-heading)]">PeerLearn</span>
            </a>
          </Link>

          {isLoggedIn && (
            <div className="hidden md:flex items-center gap-1">
              <Link href="/dashboard">
                <a data-testid="link-dashboard">
                  <Button
                    variant="ghost"
                    className={location === "/dashboard" ? "bg-accent" : ""}
                  >
                    Dashboard
                  </Button>
                </a>
              </Link>
              <Link href="/find-peers">
                <a data-testid="link-find-peers">
                  <Button
                    variant="ghost"
                    className={location === "/find-peers" ? "bg-accent" : ""}
                  >
                    Find Peers
                  </Button>
                </a>
              </Link>
              <Link href="/live-streams">
                <a data-testid="link-live-streams">
                  <Button
                    variant="ghost"
                    className={location === "/live-streams" ? "bg-accent" : ""}
                  >
                    Live Streams
                  </Button>
                </a>
              </Link>
              <Link href="/messages">
                <a data-testid="link-messages">
                  <Button
                    variant="ghost"
                    className={location === "/messages" ? "bg-accent" : ""}
                  >
                    Messages
                  </Button>
                </a>
              </Link>
            </div>
          )}

          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative"
                  data-testid="button-notifications"
                  onClick={() => console.log("Notifications clicked")}
                >
                  <Bell className="h-5 w-5" />
                  {pendingRequestsCount > 0 && (
                    <Badge
                      variant="destructive"
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                      data-testid="badge-notification-count"
                    >
                      {pendingRequestsCount}
                    </Badge>
                  )}
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-user-menu">
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={userAvatar} alt={userName} />
                        <AvatarFallback>{userName.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem data-testid="menu-profile">
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem data-testid="menu-logout" onClick={() => console.log("Logout clicked")}>
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden"
                  data-testid="button-mobile-menu"
                  onClick={() => console.log("Mobile menu clicked")}
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" onClick={onAuthClick} data-testid="button-login">
                  Login
                </Button>
                <Button onClick={onAuthClick} data-testid="button-signup">
                  Sign Up
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
