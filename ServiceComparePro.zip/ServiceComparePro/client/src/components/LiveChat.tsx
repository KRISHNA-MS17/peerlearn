import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  message: string;
  timestamp: Date;
}

interface LiveChatProps {
  messages: ChatMessage[];
  onSendMessage?: (message: string) => void;
  currentUserId?: string;
}

export default function LiveChat({ messages, onSendMessage, currentUserId = "me" }: LiveChatProps) {
  const [inputMessage, setInputMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputMessage.trim()) {
      onSendMessage?.(inputMessage);
      setInputMessage("");
    }
  };

  return (
    <div className="flex flex-col h-full border rounded-lg overflow-hidden" data-testid="live-chat">
      <div className="p-3 border-b bg-muted/30">
        <h3 className="font-semibold text-sm">Live Chat</h3>
        <p className="text-xs text-muted-foreground">{messages.length} messages</p>
      </div>

      <ScrollArea className="flex-1 p-3" ref={scrollRef}>
        <div className="space-y-3">
          {messages.map((msg) => {
            const initials = msg.userName
              .split(" ")
              .map((n) => n[0])
              .join("")
              .toUpperCase()
              .slice(0, 2);

            const isOwnMessage = msg.userId === currentUserId;

            return (
              <div
                key={msg.id}
                className={`flex gap-2 ${isOwnMessage ? "flex-row-reverse" : "flex-row"}`}
                data-testid={`chat-message-${msg.id}`}
              >
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarImage src={msg.userAvatar} alt={msg.userName} />
                  <AvatarFallback className="text-xs">{initials}</AvatarFallback>
                </Avatar>
                <div className={`flex-1 min-w-0 ${isOwnMessage ? "text-right" : "text-left"}`}>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-xs font-semibold">{msg.userName}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(msg.timestamp, { addSuffix: true })}
                    </span>
                  </div>
                  <div
                    className={`inline-block rounded-lg px-3 py-1.5 text-sm ${
                      isOwnMessage
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    {msg.message}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>

      <form onSubmit={handleSend} className="p-3 border-t">
        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            className="flex-1"
            data-testid="input-live-chat"
          />
          <Button type="submit" size="icon" data-testid="button-send-chat">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
