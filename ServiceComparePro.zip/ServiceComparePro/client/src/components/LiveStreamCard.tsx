import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, Clock } from "lucide-react";

interface LiveStreamCardProps {
  id: string;
  title: string;
  streamerName: string;
  streamerAvatar?: string;
  subject: string;
  viewerCount: number;
  isLive?: boolean;
  duration?: string;
  thumbnailUrl?: string;
  onClick?: (id: string) => void;
}

export default function LiveStreamCard({
  id,
  title,
  streamerName,
  streamerAvatar,
  subject,
  viewerCount,
  isLive = true,
  duration,
  thumbnailUrl,
  onClick,
}: LiveStreamCardProps) {
  const initials = streamerName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card
      className="overflow-hidden hover-elevate cursor-pointer"
      onClick={() => onClick?.(id)}
      data-testid={`card-stream-${id}`}
    >
      <div className="relative aspect-video bg-gradient-to-br from-primary/20 to-primary/5">
        {thumbnailUrl ? (
          <img src={thumbnailUrl} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-muted-foreground text-center">
              <Eye className="h-8 w-8 mx-auto mb-2" />
              <p className="text-xs">Live Stream</p>
            </div>
          </div>
        )}

        <div className="absolute top-2 left-2 flex gap-2">
          {isLive && (
            <Badge variant="destructive" className="animate-pulse">
              <div className="h-2 w-2 rounded-full bg-white mr-1" />
              LIVE
            </Badge>
          )}
          <Badge variant="secondary" className="backdrop-blur-sm bg-black/50 text-white">
            <Eye className="h-3 w-3 mr-1" />
            {viewerCount}
          </Badge>
        </div>

        {duration && !isLive && (
          <div className="absolute bottom-2 right-2">
            <Badge variant="secondary" className="backdrop-blur-sm bg-black/70 text-white">
              <Clock className="h-3 w-3 mr-1" />
              {duration}
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <div className="flex gap-3">
          <Avatar className="h-10 w-10 shrink-0">
            <AvatarImage src={streamerAvatar} alt={streamerName} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm line-clamp-2 mb-1" data-testid={`text-title-${id}`}>
              {title}
            </h3>
            <p className="text-xs text-muted-foreground">{streamerName}</p>
            <Badge variant="default" className="mt-2 text-xs">
              {subject}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
