import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Star, MessageSquare } from "lucide-react";

interface PeerCardProps {
  id: string;
  name: string;
  avatar?: string;
  subjectsTeaching: string[];
  subjectsLearning: string[];
  rating?: number;
  reviewCount?: number;
  availability?: string;
  onConnect?: (id: string) => void;
  onMessage?: (id: string) => void;
  connected?: boolean;
}

export default function PeerCard({
  id,
  name,
  avatar,
  subjectsTeaching,
  subjectsLearning,
  rating = 0,
  reviewCount = 0,
  availability,
  onConnect,
  onMessage,
  connected = false,
}: PeerCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card className="hover-elevate" data-testid={`card-peer-${id}`}>
      <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-4">
        <Avatar className="h-16 w-16">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-lg truncate" data-testid={`text-name-${id}`}>{name}</h3>
          {rating > 0 && (
            <div className="flex items-center gap-1 mt-1">
              <Star className="h-4 w-4 fill-primary text-primary" />
              <span className="text-sm font-medium" data-testid={`text-rating-${id}`}>{rating.toFixed(1)}</span>
              <span className="text-xs text-muted-foreground">({reviewCount} reviews)</span>
            </div>
          )}
          {availability && (
            <p className="text-xs text-muted-foreground mt-1">{availability}</p>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {subjectsTeaching.length > 0 && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Can teach:</p>
            <div className="flex flex-wrap gap-2">
              {subjectsTeaching.map((subject) => (
                <Badge key={subject} variant="default" className="text-xs" data-testid={`badge-teaching-${subject}`}>
                  {subject}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {subjectsLearning.length > 0 && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Wants to learn:</p>
            <div className="flex flex-wrap gap-2">
              {subjectsLearning.map((subject) => (
                <Badge key={subject} variant="secondary" className="text-xs" data-testid={`badge-learning-${subject}`}>
                  {subject}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex gap-2">
        {connected ? (
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => onMessage?.(id)}
            data-testid={`button-message-${id}`}
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            Message
          </Button>
        ) : (
          <Button
            className="flex-1"
            onClick={() => onConnect?.(id)}
            data-testid={`button-connect-${id}`}
          >
            Connect
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
