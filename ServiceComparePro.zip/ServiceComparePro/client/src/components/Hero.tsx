import { Button } from "@/components/ui/button";
import { Users, MessageSquare, Star } from "lucide-react";
import heroImage from '@assets/generated_images/Students_collaborating_hero_illustration_e7f59afa.png';

interface HeroProps {
  onGetStarted?: () => void;
  onLearnMore?: () => void;
}

export default function Hero({ onGetStarted, onLearnMore }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-background py-12 md:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
              Learn Together,
              <span className="text-primary"> Excel Together</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-xl">
              Connect with peer tutors who understand your courses. Share knowledge, get help, and achieve academic success through collaborative learning.
            </p>
            
            <div className="flex flex-wrap gap-3">
              <Button size="lg" onClick={onGetStarted} data-testid="button-get-started">
                Get Started Free
              </Button>
              <Button size="lg" variant="outline" onClick={onLearnMore} data-testid="button-learn-more">
                Learn More
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-6 pt-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold">5,000+</p>
                  <p className="text-xs text-muted-foreground">Active Students</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold">10,000+</p>
                  <p className="text-xs text-muted-foreground">Study Sessions</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                  <Star className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold">4.9/5</p>
                  <p className="text-xs text-muted-foreground">Average Rating</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl overflow-hidden">
              <img
                src={heroImage}
                alt="Students collaborating"
                className="w-full h-auto"
                data-testid="img-hero"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
