import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Star } from "lucide-react";

interface ReviewCardProps {
  id: string;
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;
  comment: string;
  subject: string;
  timestamp: string;
}

export default function ReviewCard({
  id,
  reviewerName,
  reviewerAvatar,
  rating,
  comment,
  subject,
  timestamp,
}: ReviewCardProps) {
  const initials = reviewerName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card data-testid={`card-review-${id}`}>
      <CardHeader className="flex flex-row items-start gap-4 space-y-0 pb-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={reviewerAvatar} alt={reviewerName} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h4 className="font-semibold text-sm" data-testid={`text-reviewer-${id}`}>{reviewerName}</h4>
              <p className="text-xs text-muted-foreground">{subject}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < rating
                      ? "fill-primary text-primary"
                      : "text-muted"
                  }`}
                />
              ))}
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-1">{timestamp}</p>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground" data-testid={`text-comment-${id}`}>{comment}</p>
      </CardContent>
    </Card>
  );
}
