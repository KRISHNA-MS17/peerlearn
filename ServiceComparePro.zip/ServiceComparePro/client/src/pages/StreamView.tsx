import { useState } from "react";
import Navbar from "@/components/Navbar";
import LiveStreamPlayer from "@/components/LiveStreamPlayer";
import LiveChat from "@/components/LiveChat";
import CommentSection from "@/components/CommentSection";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function StreamView() {
  const [, setLocation] = useLocation();

  // todo: remove mock functionality
  const [chatMessages, setChatMessages] = useState([
    {
      id: "1",
      userId: "user1",
      userName: "Sarah J.",
      message: "Great explanation!",
      timestamp: new Date(Date.now() - 300000),
    },
    {
      id: "2",
      userId: "user2",
      userName: "Jordan L.",
      userAvatar: avatar2,
      message: "Can you explain that part about chain rule again?",
      timestamp: new Date(Date.now() - 240000),
    },
    {
      id: "3",
      userId: "user3",
      userName: "Emily D.",
      message: "This is really helpful, thanks!",
      timestamp: new Date(Date.now() - 180000),
    },
  ]);

  const [comments] = useState([
    {
      id: "1",
      userId: "user1",
      userName: "Alex Chen",
      userAvatar: avatar1,
      content: "This was such a helpful stream! The way you explained derivatives really clicked for me.",
      timestamp: new Date(Date.now() - 7200000),
      likes: 12,
      hasLiked: false,
      replies: [
        {
          id: "1-1",
          userId: "user2",
          userName: "Sarah Johnson",
          userAvatar: avatar2,
          content: "I agree! The examples were really clear.",
          timestamp: new Date(Date.now() - 3600000),
          likes: 3,
          hasLiked: false,
        },
      ],
    },
    {
      id: "2",
      userId: "user3",
      userName: "Jordan Lee",
      content: "Could you do a follow-up stream on integrals?",
      timestamp: new Date(Date.now() - 5400000),
      likes: 8,
      hasLiked: true,
    },
  ]);

  const handleSendChatMessage = (message: string) => {
    const newMessage = {
      id: Date.now().toString(),
      userId: "me",
      userName: "You",
      message,
      timestamp: new Date(),
    };
    setChatMessages([...chatMessages, newMessage]);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} pendingRequestsCount={2} userName="You" userAvatar={avatar2} />

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation("/live-streams")}
            data-testid="button-back"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Streams
          </Button>
          <ThemeToggle />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <LiveStreamPlayer
              streamTitle="Calculus Study Session - Derivatives & Integrals"
              streamerName="Alex Chen"
              streamerAvatar={avatar1}
              subject="Mathematics"
              viewerCount={42}
              isLive={true}
            />

            <div className="mt-8">
              <CommentSection
                comments={comments}
                onAddComment={(content, parentId) =>
                  console.log("Add comment:", content, parentId)
                }
                onLikeComment={(id) => console.log("Like comment:", id)}
              />
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="h-[600px]">
                <LiveChat
                  messages={chatMessages}
                  onSendMessage={handleSendChatMessage}
                  currentUserId="me"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
