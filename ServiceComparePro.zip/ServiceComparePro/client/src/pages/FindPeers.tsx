import { useState } from "react";
import Navbar from "@/components/Navbar";
import SearchBar from "@/components/SearchBar";
import PeerCard from "@/components/PeerCard";
import ThemeToggle from "@/components/ThemeToggle";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { SlidersHorizontal } from "lucide-react";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

const SUBJECTS = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "English",
  "History",
  "Computer Science",
  "Economics",
];

export default function FindPeers() {
  const [filters, setFilters] = useState<{ label: string; value: string }[]>([]);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);
  const [minRating, setMinRating] = useState(0);
  const [filtersOpen, setFiltersOpen] = useState(false);

  // todo: remove mock functionality
  const peers = [
    {
      id: "1",
      name: "Alex Chen",
      avatar: avatar1,
      subjectsTeaching: ["Mathematics", "Physics"],
      subjectsLearning: ["Chemistry"],
      rating: 4.8,
      reviewCount: 23,
      availability: "Mon-Fri evenings",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      avatar: avatar2,
      subjectsTeaching: ["English", "History"],
      subjectsLearning: ["Mathematics"],
      rating: 4.9,
      reviewCount: 45,
      availability: "Weekends only",
    },
    {
      id: "3",
      name: "Jordan Lee",
      subjectsTeaching: ["Computer Science"],
      subjectsLearning: ["Data Structures"],
      rating: 5.0,
      reviewCount: 12,
      availability: "Flexible",
    },
    {
      id: "4",
      name: "Emily Davis",
      subjectsTeaching: ["Chemistry", "Biology"],
      subjectsLearning: ["Physics"],
      rating: 4.7,
      reviewCount: 18,
    },
    {
      id: "5",
      name: "Michael Brown",
      subjectsTeaching: ["Economics", "History"],
      subjectsLearning: ["English"],
      rating: 4.6,
      reviewCount: 8,
      availability: "Weekday mornings",
    },
  ];

  const handleSearch = (query: string) => {
    console.log("Search query:", query);
  };

  const handleRemoveFilter = (value: string) => {
    setFilters(filters.filter((f) => f.value !== value));
  };

  const handleApplyFilters = () => {
    const newFilters: { label: string; value: string }[] = [];
    
    selectedSubjects.forEach((subject) => {
      newFilters.push({ label: subject, value: subject.toLowerCase() });
    });
    
    if (showAvailableOnly) {
      newFilters.push({ label: "Available Now", value: "available" });
    }
    
    if (minRating > 0) {
      newFilters.push({ label: `Rating ${minRating}+`, value: `rating-${minRating}` });
    }
    
    setFilters(newFilters);
    setFiltersOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} pendingRequestsCount={2} userName="You" userAvatar={avatar2} />

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Find Peers</h1>
            <p className="text-muted-foreground">
              Search for students who can help with your subjects
            </p>
          </div>
          <ThemeToggle />
        </div>

        <div className="mb-8">
          <SearchBar
            onSearch={handleSearch}
            onFilterClick={() => setFiltersOpen(true)}
            filters={filters}
            onRemoveFilter={handleRemoveFilter}
          />
        </div>

        <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filter Results</SheetTitle>
              <SheetDescription>
                Narrow down your search to find the perfect peer tutors
              </SheetDescription>
            </SheetHeader>

            <div className="space-y-6 mt-6">
              <div>
                <Label className="text-base font-semibold mb-3 block">Subjects</Label>
                <div className="space-y-3">
                  {SUBJECTS.map((subject) => (
                    <div key={subject} className="flex items-center space-x-2">
                      <Checkbox
                        id={subject}
                        checked={selectedSubjects.includes(subject)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedSubjects([...selectedSubjects, subject]);
                          } else {
                            setSelectedSubjects(
                              selectedSubjects.filter((s) => s !== subject)
                            );
                          }
                        }}
                        data-testid={`checkbox-subject-${subject}`}
                      />
                      <Label htmlFor={subject} className="cursor-pointer">
                        {subject}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold mb-3 block">Availability</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="available"
                    checked={showAvailableOnly}
                    onCheckedChange={(checked) => setShowAvailableOnly(!!checked)}
                    data-testid="checkbox-available"
                  />
                  <Label htmlFor="available" className="cursor-pointer">
                    Show only available peers
                  </Label>
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold mb-3 block">Minimum Rating</Label>
                <div className="space-y-2">
                  {[4, 4.5, 5].map((rating) => (
                    <div key={rating} className="flex items-center space-x-2">
                      <Checkbox
                        id={`rating-${rating}`}
                        checked={minRating === rating}
                        onCheckedChange={(checked) => {
                          setMinRating(checked ? rating : 0);
                        }}
                        data-testid={`checkbox-rating-${rating}`}
                      />
                      <Label htmlFor={`rating-${rating}`} className="cursor-pointer">
                        {rating}+ stars
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setSelectedSubjects([]);
                    setShowAvailableOnly(false);
                    setMinRating(0);
                    setFilters([]);
                  }}
                  data-testid="button-clear-filters"
                >
                  Clear All
                </Button>
                <Button
                  className="flex-1"
                  onClick={handleApplyFilters}
                  data-testid="button-apply-filters"
                >
                  Apply Filters
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <div className="mb-4">
          <p className="text-sm text-muted-foreground">
            Found {peers.length} peer tutors
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {peers.map((peer) => (
            <PeerCard
              key={peer.id}
              {...peer}
              onConnect={(id) => console.log("Connect with", id)}
              onMessage={(id) => console.log("Message", id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
