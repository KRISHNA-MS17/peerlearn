import { useState } from "react";
import Navbar from "@/components/Navbar";
import LiveStreamCard from "@/components/LiveStreamCard";
import StartStreamDialog from "@/components/StartStreamDialog";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Video, Radio } from "lucide-react";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';
import { useLocation } from "wouter";

export default function LiveStreams() {
  const [, setLocation] = useLocation();
  const [startStreamOpen, setStartStreamOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("live");

  // todo: remove mock functionality
  const liveStreams = [
    {
      id: "1",
      title: "Calculus Study Session - Derivatives & Integrals Explained",
      streamerName: "Alex Chen",
      streamerAvatar: avatar1,
      subject: "Mathematics",
      viewerCount: 42,
      isLive: true,
    },
    {
      id: "2",
      title: "Physics Problem Solving - Mechanics & Forces",
      streamerName: "Sarah Johnson",
      streamerAvatar: avatar2,
      subject: "Physics",
      viewerCount: 28,
      isLive: true,
    },
    {
      id: "3",
      title: "English Literature Discussion - Shakespeare Analysis",
      streamerName: "Jordan Lee",
      subject: "English",
      viewerCount: 15,
      isLive: true,
    },
    {
      id: "4",
      title: "Computer Science Tutorial - Data Structures & Algorithms",
      streamerName: "Emily Davis",
      subject: "Computer Science",
      viewerCount: 56,
      isLive: true,
    },
  ];

  const pastStreams = [
    {
      id: "5",
      title: "Chemistry Lab Review - Organic Compounds",
      streamerName: "Michael Brown",
      subject: "Chemistry",
      viewerCount: 34,
      isLive: false,
      duration: "1:24:15",
    },
    {
      id: "6",
      title: "Biology Deep Dive - Cell Structure",
      streamerName: "Sarah Johnson",
      streamerAvatar: avatar2,
      subject: "Biology",
      viewerCount: 22,
      isLive: false,
      duration: "56:30",
    },
  ];

  const handleStartStream = (data: any) => {
    console.log("Starting stream with:", data);
    setStartStreamOpen(false);
    setLocation("/stream/broadcasting");
  };

  const handleStreamClick = (id: string) => {
    console.log("View stream:", id);
    setLocation(`/stream/${id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} pendingRequestsCount={2} userName="You" userAvatar={avatar2} />

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Live Study Sessions</h1>
            <p className="text-muted-foreground">
              Join live streams or start your own to teach and learn together
            </p>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button onClick={() => setStartStreamOpen(true)} data-testid="button-go-live">
              <Radio className="mr-2 h-4 w-4" />
              Go Live
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="live" className="gap-2" data-testid="tab-live">
              <div className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
              Live Now ({liveStreams.length})
            </TabsTrigger>
            <TabsTrigger value="past" data-testid="tab-past">
              <Video className="h-4 w-4 mr-2" />
              Past Streams
            </TabsTrigger>
          </TabsList>

          <TabsContent value="live" className="space-y-6">
            {liveStreams.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {liveStreams.map((stream) => (
                  <LiveStreamCard
                    key={stream.id}
                    {...stream}
                    onClick={handleStreamClick}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Radio className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">No Live Streams</h3>
                <p className="text-muted-foreground mb-6">
                  Be the first to start a live study session!
                </p>
                <Button onClick={() => setStartStreamOpen(true)}>
                  <Radio className="mr-2 h-4 w-4" />
                  Start Streaming
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="past" className="space-y-6">
            {pastStreams.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pastStreams.map((stream) => (
                  <LiveStreamCard
                    key={stream.id}
                    {...stream}
                    onClick={handleStreamClick}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Video className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">No Past Streams</h3>
                <p className="text-muted-foreground">
                  Recorded streams will appear here
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <StartStreamDialog
        open={startStreamOpen}
        onOpenChange={setStartStreamOpen}
        onStartStream={handleStartStream}
      />
    </div>
  );
}
