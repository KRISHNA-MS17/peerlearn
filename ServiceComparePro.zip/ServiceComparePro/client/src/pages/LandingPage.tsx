import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import AuthDialog from "@/components/AuthDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Search, MessageSquare, Star, BookOpen, TrendingUp } from "lucide-react";
import conceptImage from '@assets/generated_images/Peer_connection_concept_illustration_26094501.png';

export default function LandingPage() {
  const [authDialogOpen, setAuthDialogOpen] = useState(false);

  const features = [
    {
      icon: <Search className="h-6 w-6 text-primary" />,
      title: "Find Perfect Matches",
      description: "Our smart matching system connects you with peers who excel in subjects you need help with.",
    },
    {
      icon: <MessageSquare className="h-6 w-6 text-primary" />,
      title: "Real-Time Chat",
      description: "Communicate instantly with your study partners through our integrated messaging system.",
    },
    {
      icon: <Star className="h-6 w-6 text-primary" />,
      title: "Rated & Reviewed",
      description: "Build your reputation with peer reviews and ratings from successful study sessions.",
    },
    {
      icon: <BookOpen className="h-6 w-6 text-primary" />,
      title: "Multiple Subjects",
      description: "From mathematics to literature, find help across all your courses in one platform.",
    },
    {
      icon: <Users className="h-6 w-6 text-primary" />,
      title: "Collaborative Learning",
      description: "Learn together, teach together. Build a community of knowledge sharing.",
    },
    {
      icon: <TrendingUp className="h-6 w-6 text-primary" />,
      title: "Track Progress",
      description: "Monitor your learning journey with session history and achievement tracking.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={false} onAuthClick={() => setAuthDialogOpen(true)} />
      
      <Hero
        onGetStarted={() => setAuthDialogOpen(true)}
        onLearnMore={() => {
          document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
        }}
      />

      <section id="features" className="py-16 md:py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need to Learn Together
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              PeerLearn provides all the tools you need for successful peer-to-peer learning
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate" data-testid={`card-feature-${index}`}>
                <CardHeader>
                  <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                How PeerLearn Works
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
                    1
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Create Your Profile</h3>
                    <p className="text-muted-foreground">
                      Share what subjects you excel at and what you need help with
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
                    2
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Get Matched</h3>
                    <p className="text-muted-foreground">
                      Our system finds peers who can help you and peers you can help
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
                    3
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Connect & Learn</h3>
                    <p className="text-muted-foreground">
                      Chat with your matches and schedule study sessions together
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
                    4
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Rate & Review</h3>
                    <p className="text-muted-foreground">
                      Share feedback to help build a trusted learning community
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <img
                src={conceptImage}
                alt="Peer learning concept"
                className="w-full max-w-md rounded-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Learning Together?
          </h2>
          <p className="text-lg mb-8 text-primary-foreground/90">
            Join thousands of students helping each other succeed
          </p>
          <button
            onClick={() => setAuthDialogOpen(true)}
            className="inline-flex items-center justify-center rounded-lg px-8 py-3 text-base font-semibold bg-background text-foreground hover-elevate active-elevate-2"
            data-testid="button-cta-signup"
          >
            Get Started for Free
          </button>
        </div>
      </section>

      <footer className="border-t py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <p className="text-center text-sm text-muted-foreground">
            © 2025 PeerLearn. Empowering students through collaborative learning.
          </p>
        </div>
      </footer>

      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />
    </div>
  );
}
