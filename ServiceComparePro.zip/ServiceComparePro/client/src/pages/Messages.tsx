import { useState } from "react";
import Navbar from "@/components/Navbar";
import MessageThread from "@/components/MessageThread";
import ThemeToggle from "@/components/ThemeToggle";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

interface Conversation {
  id: string;
  peerName: string;
  peerAvatar?: string;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
}

export default function Messages() {
  // todo: remove mock functionality
  const conversations: Conversation[] = [
    {
      id: "1",
      peerName: "Alex Chen",
      peerAvatar: avatar1,
      lastMessage: "Thanks for the help with calculus!",
      timestamp: "2h ago",
      unread: true,
    },
    {
      id: "2",
      peerName: "Sarah Johnson",
      peerAvatar: avatar2,
      lastMessage: "See you at the library tomorrow",
      timestamp: "5h ago",
      unread: false,
    },
    {
      id: "3",
      peerName: "Jordan Lee",
      lastMessage: "Can we reschedule our session?",
      timestamp: "1d ago",
      unread: true,
    },
  ];

  const [selectedConversation, setSelectedConversation] = useState<string>(conversations[0].id);

  const sampleMessages = [
    {
      id: "1",
      senderId: "peer",
      content: "Hey! Thanks for connecting. When are you free for a study session?",
      timestamp: new Date(Date.now() - 3600000),
      isOwn: false,
    },
    {
      id: "2",
      senderId: "me",
      content: "Hi! I'm available tomorrow evening around 6 PM. Does that work for you?",
      timestamp: new Date(Date.now() - 3000000),
      isOwn: true,
    },
    {
      id: "3",
      senderId: "peer",
      content: "Perfect! Let's meet at the library. I'll bring my calculus notes.",
      timestamp: new Date(Date.now() - 2400000),
      isOwn: false,
    },
    {
      id: "4",
      senderId: "me",
      content: "Sounds great! See you then.",
      timestamp: new Date(Date.now() - 1800000),
      isOwn: true,
    },
  ];

  const currentPeer = conversations.find((c) => c.id === selectedConversation);

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} pendingRequestsCount={2} userName="You" userAvatar={avatar2} />

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Messages</h1>
            <p className="text-muted-foreground">
              Chat with your peer connections
            </p>
          </div>
          <ThemeToggle />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="border rounded-lg overflow-hidden">
              <div className="p-4 border-b bg-muted/30">
                <h2 className="font-semibold">Conversations</h2>
              </div>
              <ScrollArea className="h-[600px]">
                <div className="divide-y">
                  {conversations.map((conversation) => {
                    const initials = conversation.peerName
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()
                      .slice(0, 2);

                    return (
                      <button
                        key={conversation.id}
                        onClick={() => setSelectedConversation(conversation.id)}
                        className={`w-full p-4 flex items-start gap-3 hover-elevate text-left ${
                          selectedConversation === conversation.id ? "bg-accent" : ""
                        }`}
                        data-testid={`button-conversation-${conversation.id}`}
                      >
                        <Avatar className="h-12 w-12 shrink-0">
                          <AvatarImage src={conversation.peerAvatar} alt={conversation.peerName} />
                          <AvatarFallback>{initials}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h3 className="font-semibold text-sm truncate">
                              {conversation.peerName}
                            </h3>
                            {conversation.unread && (
                              <Badge variant="default" className="h-2 w-2 p-0 rounded-full" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground truncate">
                            {conversation.lastMessage}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {conversation.timestamp}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>
          </div>

          <div className="lg:col-span-2">
            {currentPeer && (
              <MessageThread
                peerName={currentPeer.peerName}
                peerAvatar={currentPeer.peerAvatar}
                messages={sampleMessages}
                onSendMessage={(content) => console.log("Send message:", content)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
