import { useState } from "react";
import Navbar from "@/components/Navbar";
import DashboardStats from "@/components/DashboardStats";
import PeerCard from "@/components/PeerCard";
import ConnectionRequest from "@/components/ConnectionRequest";
import ThemeToggle from "@/components/ThemeToggle";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("matches");

  // todo: remove mock functionality
  const suggestedMatches = [
    {
      id: "1",
      name: "Alex Chen",
      avatar: avatar1,
      subjectsTeaching: ["Mathematics", "Physics"],
      subjectsLearning: ["Chemistry"],
      rating: 4.8,
      reviewCount: 23,
      availability: "Mon-Fri evenings",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      avatar: avatar2,
      subjectsTeaching: ["English Literature", "History"],
      subjectsLearning: ["Mathematics"],
      rating: 4.9,
      reviewCount: 45,
      availability: "Weekends only",
    },
    {
      id: "3",
      name: "Jordan Lee",
      subjectsTeaching: ["Computer Science", "Web Development"],
      subjectsLearning: ["Data Structures"],
      rating: 5.0,
      reviewCount: 12,
    },
  ];

  const connectionRequests = [
    {
      id: "1",
      name: "Emily Davis",
      subject: "Chemistry",
      message: "Hi! I saw you're good at organic chemistry. I'd love your help!",
      timestamp: "2 hours ago",
    },
    {
      id: "2",
      name: "Michael Brown",
      avatar: avatar1,
      subject: "Physics",
      message: "Can you help me with quantum mechanics?",
      timestamp: "5 hours ago",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        isLoggedIn={true}
        pendingRequestsCount={connectionRequests.length}
        userName="You"
        userAvatar={avatar2}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back! Here's your learning overview
            </p>
          </div>
          <ThemeToggle />
        </div>

        <div className="mb-8">
          <DashboardStats
            matches={8}
            pendingRequests={connectionRequests.length}
            totalSessions={24}
            averageRating={4.8}
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="matches" data-testid="tab-matches">
              Suggested Matches
            </TabsTrigger>
            <TabsTrigger value="requests" data-testid="tab-requests">
              Requests ({connectionRequests.length})
            </TabsTrigger>
            <TabsTrigger value="connections" data-testid="tab-connections">
              My Connections
            </TabsTrigger>
          </TabsList>

          <TabsContent value="matches" className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Suggested Peer Matches</h2>
              <p className="text-muted-foreground mb-6">
                These students can help with subjects you're learning
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {suggestedMatches.map((peer) => (
                  <PeerCard
                    key={peer.id}
                    {...peer}
                    onConnect={(id) => console.log("Connect with", id)}
                    onMessage={(id) => console.log("Message", id)}
                  />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="requests" className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Connection Requests</h2>
              <p className="text-muted-foreground mb-6">
                Students who want to connect with you
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl">
                {connectionRequests.map((request) => (
                  <ConnectionRequest
                    key={request.id}
                    {...request}
                    onAccept={(id) => console.log("Accept request", id)}
                    onDecline={(id) => console.log("Decline request", id)}
                  />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="connections" className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Your Active Connections</h2>
              <p className="text-muted-foreground mb-6">
                Students you're currently connected with
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {suggestedMatches.slice(0, 2).map((peer) => (
                  <PeerCard
                    key={peer.id}
                    {...peer}
                    connected={true}
                    onConnect={(id) => console.log("Connect with", id)}
                    onMessage={(id) => console.log("Message", id)}
                  />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
