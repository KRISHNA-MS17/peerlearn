import { useState } from "react";
import Navbar from "@/components/Navbar";
import ProfileForm from "@/components/ProfileForm";
import ThemeToggle from "@/components/ThemeToggle";
import ReviewCard from "@/components/ReviewCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import avatar1 from '@assets/generated_images/Student_profile_avatar_example_1a753e1c.png';
import avatar2 from '@assets/generated_images/Second_student_avatar_example_5065f207.png';

export default function Profile() {
  const [activeTab, setActiveTab] = useState("edit");

  // todo: remove mock functionality
  const reviews = [
    {
      id: "1",
      reviewerName: "Emily Davis",
      rating: 5,
      comment: "Excellent tutor! Very patient and explains concepts clearly. Really helped me understand calculus.",
      subject: "Mathematics",
      timestamp: "2 days ago",
    },
    {
      id: "2",
      reviewerName: "Michael Brown",
      reviewerAvatar: avatar1,
      rating: 4,
      comment: "Great session! Would definitely recommend. Very knowledgeable about the subject.",
      subject: "Physics",
      timestamp: "1 week ago",
    },
    {
      id: "3",
      reviewerName: "Jordan Lee",
      rating: 5,
      comment: "Amazing help with my chemistry homework. Made everything so much easier to understand!",
      subject: "Chemistry",
      timestamp: "2 weeks ago",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} pendingRequestsCount={2} userName="You" userAvatar={avatar2} />

      <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">My Profile</h1>
            <p className="text-muted-foreground">
              Manage your profile and view your reviews
            </p>
          </div>
          <ThemeToggle />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="edit" data-testid="tab-edit-profile">
              Edit Profile
            </TabsTrigger>
            <TabsTrigger value="reviews" data-testid="tab-reviews">
              My Reviews ({reviews.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="edit" className="space-y-6">
            <ProfileForm
              initialData={{
                name: "Your Name",
                bio: "Tell peers about yourself and your learning goals...",
                avatar: avatar2,
                subjectsTeaching: ["Mathematics", "Computer Science"],
                subjectsLearning: ["Physics"],
                availability: "Mon-Fri evenings",
              }}
              onSubmit={(data) => console.log("Profile submitted:", data)}
            />
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Reviews from Peers</h2>
              <p className="text-muted-foreground mb-6">
                See what other students think about your tutoring
              </p>
              <div className="space-y-4">
                {reviews.map((review) => (
                  <ReviewCard key={review.id} {...review} />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
