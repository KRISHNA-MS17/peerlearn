# PeerLearn Design Guidelines

## Design Approach

**Selected Approach:** Reference-based, inspired by modern EdTech platforms (Coursera, Notion, Linear)

**Key Principles:**
- Clean, minimalist layouts that reduce cognitive load for students
- Card-based architecture for easy scanning of peer profiles and information
- Generous whitespace to create breathing room in information-dense interfaces
- Friendly, approachable aesthetic that balances professionalism with student accessibility

## Typography System

**Font Families:**
- Primary: 'Inter' (Google Fonts) - for UI elements, navigation, body text
- Headings: 'Plus Jakarta Sans' (Google Fonts) - for page titles, card headers

**Type Scale:**
- Hero/Page Titles: text-4xl md:text-5xl font-bold
- Section Headers: text-2xl md:text-3xl font-semibold
- Card Titles: text-lg font-semibold
- Body Text: text-base font-normal
- Small Text/Labels: text-sm font-medium
- Captions: text-xs font-normal

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Tight spacing: p-2, gap-2 (within components)
- Standard spacing: p-4, gap-4 (cards, form fields)
- Section padding: py-8 md:py-12 (between major sections)
- Container spacing: px-4 md:px-6 lg:px-8
- Large gaps: gap-8, gap-12 (between major elements)

**Container Widths:**
- Main content: max-w-7xl mx-auto
- Dashboard content: max-w-6xl mx-auto
- Forms/narrow content: max-w-2xl mx-auto
- Profile cards grid: max-w-5xl mx-auto

**Grid Systems:**
- Peer profile cards: grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Dashboard stats: grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4
- Subject tags: flex flex-wrap gap-2
- Two-column layouts: grid grid-cols-1 lg:grid-cols-2 gap-8

## Component Library

### Navigation
- Top navigation bar: sticky top-0 with backdrop-blur effect
- Height: h-16
- Logo left-aligned, navigation center, user profile right
- Mobile: Hamburger menu revealing slide-in drawer
- Include notification bell icon with badge for pending requests

### Authentication Pages (Login/Signup)
- Centered card layout: max-w-md mx-auto
- Split design: Form on left, illustration or benefits list on right (desktop only)
- Social login buttons prominently displayed
- Clean form fields with generous spacing (gap-6)

### Hero Section (Landing/Home)
- Height: min-h-[500px] md:min-h-[600px] (not full viewport)
- Two-column layout: Text content left, illustration/image right
- Headline + subheadline + dual CTAs ("Get Started" + "Learn More")
- Include trust indicators: "Join 5,000+ students helping each other"

### Profile Cards
- Rounded cards: rounded-xl with subtle shadow
- Structure: Profile photo (top or left), name, subjects taught (pill badges), rating stars, "Connect" button
- Hover state: subtle lift effect (translate-y-1)
- Avatar: rounded-full w-16 h-16 (in lists), w-24 h-24 (profile page)

### Dashboard Layout
- Sidebar navigation (left): w-64, hidden on mobile, drawer on tablet
- Main content area: flex-1 with proper padding
- Top stats bar: 4 metric cards showing matches, requests, sessions, rating
- Sections: "Suggested Matches", "Your Requests", "Upcoming Sessions"

### Subject Tags/Pills
- Rounded badges: rounded-full px-3 py-1
- Different visual weight for "teaches" vs "needs help"
- Clickable tags in search/filter contexts

### Search & Filter Interface
- Search bar: Prominent position, rounded-lg with search icon
- Filter chips below search: Subject, Availability, Rating
- Results grid below with loading states and empty states

### Messaging Interface
- Split view: Conversation list (left sidebar, w-80), active chat (right, flex-1)
- Message bubbles: Differentiate sent vs received with alignment
- Rounded corners: rounded-2xl for message bubbles
- Avatar indicators in conversation list
- Input bar: Fixed bottom with rounded input field and send button

### Rating & Review Component
- Star rating: Large, interactive stars (5-star system)
- Text area for written feedback: min-h-32
- Display format: Stars + reviewer name + date + review text
- Card-based layout for review display

### Request/Match Cards
- Pending requests: Outlined cards with "Accept" and "Decline" buttons
- Accepted matches: Filled cards with "Message" button
- Include subject context and availability information
- Badge indicators for status (Pending, Active, Completed)

### Form Elements
- Input fields: rounded-lg h-12 with border
- Labels: text-sm font-medium mb-2
- Consistent spacing between form groups: space-y-6
- Multi-select for subjects: Tag-based interface with autocomplete
- Time availability: Grid of selectable time slots
- File upload (profile photo): Drag-drop zone or click to upload, circular preview

### Buttons
- Primary CTA: rounded-lg px-6 py-3 font-semibold
- Secondary: outlined version with transparent background
- Icon buttons: rounded-full w-10 h-10
- Button groups: Consistent spacing with gap-3

### Modals/Dialogs
- Centered overlay with backdrop
- Max width: max-w-lg
- Rounded corners: rounded-xl
- Proper padding: p-6
- Header with close button (X icon)

### Empty States
- Icon + Heading + Description + CTA
- Centered layout with max-w-md
- Friendly, encouraging messaging
- Example: "No matches yet - Update your profile to find study partners!"

## Images

**Profile Photos:**
- Required for all student profiles
- Circular avatars throughout the app
- Sizes: 64px (cards), 96px (profile headers), 40px (chat/comments)
- Placeholder: Initials on gradient background for missing photos

**Hero Section Image:**
- Right-side illustration showing students collaborating or studying together
- Modern, friendly illustration style (not photography)
- Dimensions: Approximately 600x500px, responsive
- Purpose: Reinforce the peer-to-peer learning concept

**Dashboard Illustrations:**
- Small spot illustrations for empty states
- Celebratory graphics for milestones (first match, high rating)
- Subject-specific icons for different categories

**Subject Category Icons:**
- Use Heroicons for subject representations (beaker for science, calculator for math, etc.)
- Size: w-6 h-6 in cards, w-8 h-8 in headers

## Animations

**Minimal, purposeful animations only:**
- Page transitions: Simple fade-in
- Card hover: Subtle lift (transform: translateY(-2px))
- Button press: Scale down slightly (scale-95)
- Loading states: Gentle pulse on skeleton screens
- Match notification: Subtle slide-in from top
- No heavy scroll-triggered animations or complex transitions

## Responsive Behavior

**Breakpoints:**
- Mobile: < 768px - Single column, stacked navigation
- Tablet: 768px-1024px - Two columns where appropriate
- Desktop: > 1024px - Full multi-column layouts

**Mobile Optimizations:**
- Collapsible navigation drawer
- Profile cards stack vertically
- Chat interface: Show conversation list OR active chat (toggle view)
- Reduce padding/spacing by 50% on mobile
- Touch-friendly button sizes (min 44px height)

## Accessibility

- Maintain WCAG AA contrast standards
- Focus indicators on all interactive elements
- ARIA labels for icon-only buttons
- Keyboard navigation support for all features
- Screen reader friendly form labels and error messages
- Clear visual feedback for all actions (request sent, message delivered)